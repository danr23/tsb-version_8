counter = 0;
counterP = 0;
colTsbT = new Array("#00aa00", "#00bb00", "#00cc00", "#00dd00", "#00ee00", "#00ff00", "#000000");
colTsbTP = new Array("#00aa00", "#00bb00", "#00cc00", "#00dd00", "#00ee00", "#00ff00", "#000000");
function selectionClear() {
document.getElementById("tsbT").focus();
document.getElementById("tsbT").selectionEnd = 0;
function tsbTColor() {
document.getElementById("tsbT").style.color = colTsbT[counter++];
if (counter > colTsbT.length) counter = 0;
}
setInterval(tsbTColor, 100);
document.getElementById("soundForCopy").setAttribute('src', 'copySounds/coordinates/' + Math.ceil(Math.floor(Math.random()*2)) + '.ogg');
document.getElementById("soundForCopy").setAttribute('autoplay', 'autoplay');
}
function copyCoordinates() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").focus();
document.getElementById("tsbT").selectionStart = 0;
setTimeout(function() {
document.getElementById("tsbT").selectionEnd = 1;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 100);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 2;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 200);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 3;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 300);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 4;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 400);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 5;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 500);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 6;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 600);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 7;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 700);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 8;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 800);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 9;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 900);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 10;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1000);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 11;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1100);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 12;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1200);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 13;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1300);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 14;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1400);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 15;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1500);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 16;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1600);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 17;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1700);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 18;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1800);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 19;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 1900);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 20;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2000);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 21;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2100);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 22;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2200);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 23;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2300);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 24;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2400);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 25;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2500);
setTimeout(function() {
document.getElementById("tsbT").removeAttribute("disabled");
document.getElementById("tsbT").selectionEnd = 26;
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2600);
setTimeout(function() {
document.execCommand('copy');
document.getElementById("resultCopy").childNodes[0].nodeValue = document.getElementById("tsbT").value;
selectionClear();
document.getElementById("tsbT").setAttribute("disabled", "true");
}, 2650);
}
function selectionClearPASS() {
document.getElementById("tsbTP").focus();
document.getElementById("tsbTP").selectionEnd = 0;
function tsbTPColor() {
document.getElementById("tsbTP").style.color = colTsbTP[counterP++];
if (counterP > colTsbTP.length) counterP = 0;
}
setInterval(tsbTPColor, 100);
document.getElementById("soundForCopy").setAttribute('src', 'copySounds/password/' + Math.ceil(Math.floor(Math.random()*2)) + '.ogg');
document.getElementById("soundForCopy").setAttribute('autoplay', 'autoplay');
}
function copyPassword() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").focus();
document.getElementById("tsbTP").selectionStart = 0;
setTimeout(function() {
document.getElementById("tsbTP").selectionEnd = 1;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 100);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 2;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 200);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 3;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 300);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 4;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 400);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 5;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 500);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 6;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 600);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 7;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 700);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 8;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 800);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 9;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 900);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 10;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1000);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 11;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1100);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 12;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1200);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 13;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1300);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 14;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1400);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 15;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1500);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 16;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1600);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 17;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1700);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 18;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1800);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 19;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 1900);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 20;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 2000);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 21;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 2100);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 22;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 2200);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 23;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 2300);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 24;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 2400);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 25;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 2500);
setTimeout(function() {
document.getElementById("tsbTP").removeAttribute("disabled");
document.getElementById("tsbTP").selectionEnd = 26;
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 2600);
setTimeout(function() {
document.execCommand('copy');
document.getElementById("resultCopyP").childNodes[0].nodeValue = document.getElementById("tsbTP").value;
selectionClearPASS();
document.getElementById("tsbTP").setAttribute("disabled", "true");
}, 2650);
}
